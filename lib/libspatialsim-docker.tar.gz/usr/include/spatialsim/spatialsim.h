#ifndef SPATIALSIM_H_
#define SPATIALSIM_H_

#include "mystruct.h"
#include "options.h"
#include "spatialsimulator.h"

#endif
